// App.js
import React from 'react';
import {SafeAreaView, View, Text, ScrollView, TouchableOpacity, Image, StatusBar } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import MaterialIcon from 'react-native-vector-icons/MaterialIcons';
import styles from './styles';

export default function Home(){ 
  return (
    <SafeAreaView style={styles.container}>
      {/* Feed Content */}
      <ScrollView style={styles.feedContainer}>
        {/*Header*/}
      <View style={styles.Header}>
        {/*View informações user*/}
        <View style={styles.userContainer}>
          <View style={styles.infoUser}>
            <Text>Olá, Usuário(a)</Text>
          </View>
          <View style={styles.msgUser}>
            <Text>Bem Vindo de volta</Text>
          </View>
        </View>
        {/*View Storys*/}
        <View>

        </View>
      </View>
        {/* Post 1 */}
        <View style={styles.postContainer}>
          <View style={styles.postHeader}>
            <Text style={styles.institutionText}>Itaú Instituição · 1h ···</Text>
          </View>
          <Text style={styles.postText}>
            Itaú é doidera cara, desde criancinha to usando ele cara, sério.
          </Text>
          <View style={styles.postContent}></View>
          <View style={styles.postActions}>
            <TouchableOpacity style={styles.actionButton}>
              <Icon name="message-circle" size={20} color="#666" />
              <Text style={styles.actionText}>3</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton}>
              <Icon name="repeat" size={20} color="#666" />
              <Text style={styles.actionText}>5</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton}>
              <Icon name="heart" size={20} color="#666" />
              <Text style={styles.actionText}>2</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton}>
              <Icon name="download" size={20} color="#666" />
            </TouchableOpacity>
          </View>
        </View>
        
        {/* Post 2 */}
        <View style={styles.postContainer}>
          <View style={styles.postHeader}>
            <Text style={styles.institutionText}>Itaú Instituição · 1h ···</Text>
          </View>
          <Text style={styles.postText}>
            Itaú é doidera cara, desde criancinha to usando ele cara, sério.
          </Text>
          <View style={styles.postContent}></View>
        </View>
      </ScrollView>
      
      {/* Send Button */}
      <TouchableOpacity style={styles.sendButton}>
        <Icon name="send" size={24} color="#FFFFFF" />
      </TouchableOpacity>
    </SafeAreaView>
  );
};

