import { StyleSheet } from "react-native";

export default StyleSheet.create({
  
    container: {
        flex: 1,
        backgroundColor: '#FFFFFF',
      },
      feedContainer: {
        flex: 1,
        paddingHorizontal: 16,
      },
      postContainer: {
        marginBottom: 20,
      },
      postHeader: {
        marginBottom: 8,
      },
      institutionText: {
        fontSize: 14,
        color: '#333',
      },
      postText: {
        fontSize: 14,
        marginBottom: 10,
      },
      postContent: {
        height: 120,
        backgroundColor: '#F0F0F0',
        borderRadius: 8,
        marginBottom: 8,
      },
      postActions: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
      },
      actionButton: {
        flexDirection: 'row',
        alignItems: 'center',
        marginRight: 20,
      },
      actionText: {
        marginLeft: 5,
        fontSize: 12,
        color: '#666',
      },
      sendButton: {
        position: 'absolute',
        right: 20,
        bottom: 20,
        width: 50,
        height: 50,
        borderRadius: 25,
        backgroundColor: '#3B82F6',
        justifyContent: 'center',
        alignItems: 'center',
        elevation: 5,
      },
      Header:{
        flex: 2,
        paddingBottom: 30,
      },
      userContainer:{

      },
      infoUser:{

      },
      msgUser:{

      }

});