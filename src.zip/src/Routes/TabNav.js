import * as React from 'react';
import {Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Home from '../Screens/Home';

const Tab = createBottomTabNavigator();

//Essas functions simulam telas

function ViewHome(){
  return (
    <View style={{justifyContent:'center', alignItems:'center', flex:1}}>
      <Text>Home</Text>
    </View>
  )
}
function ViewConfigUser(){
  return (
    <View style={{justifyContent:'center', alignItems:'center', flex:1}}>
      <Text>ViewConfigUser</Text>
    </View>
  )
}
function ViewPesquisa(){
  return (
    <View style={{justifyContent:'center', alignItems:'center', flex:1}}>
      <Text>ViewPesquisa</Text>
    </View>
  )
}
function ViewPost(){
  return (
    <View style={{justifyContent:'center', alignItems:'center', flex:1}}>
      <Text>ViewPost</Text>
    </View>
  )
}
function ViewAdd(){
  return (
    <View style={{justifyContent:'center', alignItems:'center', flex:1}}>
      <Text>ViewAdd</Text>
    </View>
  )
}

const TabNav = () => {
  return (
      <Tab.Navigator
        screenOptions={({route}) => ({
          headerShown: false,
          tabBarShowLabel: false,
          tabBarIcon: ({focused, color, size}) => {
            
            let nomeIcone;

            if (route.name === 'home') {
              nomeIcone = focused ? 'home' : 'home-outline';
            }else if (route.name === 'pesquisa'){
              nomeIcone = focused ? 'search' : 'search-outline'
            }else if (route.name === 'post'){
              nomeIcone = focused ? 'paper-plane' : 'paper-plane-outline'
            }
            else if (route.name === 'add'){
              nomeIcone = focused ? 'add' : 'add-outline'
            }
            else if (route.name === 'user'){
              nomeIcone = focused ? 'person-circle' : 'person-circle-outline'
            }

            return <Ionicons name={nomeIcone} size={size} color={color}/>
          
          }
        })
      }
      >
        <Tab.Screen name='home' component={Home}/>
        <Tab.Screen name='post' component={ViewPost}/>
        <Tab.Screen name='add' component={ViewAdd}/>
        <Tab.Screen name='pesquisa' component={ViewPesquisa}/>
        <Tab.Screen name='user' component={ViewConfigUser}/>
        
      </Tab.Navigator>
  );
}
export default TabNav
