import { StatusBar } from 'expo-status-bar';
import {Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import TabNav from './TabNav';

const Stack = createNativeStackNavigator();

export default function StackRoutes() {
  return (
      <Stack.Navigator>
        <Stack.Screen 
        name="Home" 
        component={TabNav}
        options={{
          headerShown: false,
        }}
        />
      
      <Stack.Screen 
        name="Login" 
        component={TabNav}
        options={{
          //configuração Cabeçalho
          headerStyle: {backgroundColor: "#32CD32"},
          headerTintColor: "#FFFFFF",
        }}
        />
      </Stack.Navigator>

  );
} 